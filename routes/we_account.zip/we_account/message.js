/**
 * Created by Administrator on 14-12-17.
 */

function getNormalMsg(req,res){

}