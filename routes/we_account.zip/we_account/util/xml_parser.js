/**
 * Created by Administrator on 14-12-17.
 */
var util = require("util"),
    xml = require("node-xml");

function xmlParse(dataString,callback){
    var result = {},
        currEle = '';
    var parser = new xml.SaxParser(function(cb) {
        cb.onStartDocument(function() {

        });
        cb.onStartElementNS(function(elem, attrs, prefix, uri, namespaces) {
            console.log(elem);
            currEle = elem;
            result[currEle] = '';
        });
        cb.onEndElementNS(function(elem, prefix, uri) {
//        util.log("<= End: " + elem + " uri="+uri + "\n");
//            parser.pause();// pause the parser
//            setTimeout(function (){parser.resume();}, 200); //resume the parser
        });
        cb.onCharacters(function(chars) {
            result[currEle] = chars;
            util.log('<CHARS>'+chars+"</CHARS>");
        });
        cb.onCdata(function(cdata) {
            result[currEle] = cdata;
            util.log('<CDATA>'+cdata+"</CDATA>");
        });
        cb.onComment(function(msg) {
            util.log('<COMMENT>'+msg+"</COMMENT>");
        });
        cb.onWarning(function(msg) {
            util.log('<WARNING>'+msg+"</WARNING>");
        });
        cb.onError(function(msg) {
            util.log('<ERROR>'+JSON.stringify(msg)+"</ERROR>");
        });
        cb.onEndDocument(function() {
            console.log("the end of xml");
            callback(result);
        });
    });
    parser.parseString(dataString);
}
//xmlParse("<xml>" +
//    "<ToUserName><![CDATA[toUser]]></ToUserName>" +
//    "<FromUserName><![CDATA[FromUser]]></FromUserName>" +
//    "<CreateTime>123456789</CreateTime>" +
//    "<MsgType><![CDATA[event]]></MsgType>" +
//    "<Event><![CDATA[subscribe]]></Event></xml>",function(result){
//    console.log("*****************************");
//    for(var key in result){
//        console.log(key+": "+result[key]);
//    }
//})

exports.parseXml = xmlParse;